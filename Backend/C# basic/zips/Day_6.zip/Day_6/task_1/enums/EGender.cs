﻿using System;
using System.Collections.Generic;
using System.Text;

namespace task_1.enums
{
    enum EGender
    {
        Male, female
    }
}
