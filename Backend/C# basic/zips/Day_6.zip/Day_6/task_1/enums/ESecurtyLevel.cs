﻿using System;
using System.Collections.Generic;
using System.Text;

namespace task_1.enums
{
    
    enum ESecurtyLevel
    {
        Guest,Developer,Secretary,DBA
    }
}
