﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day_1
{
 public enum  Gender
    {
        Male,Female
    }
}
