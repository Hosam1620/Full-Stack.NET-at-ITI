﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day_4
{
   public delegate string MyDelegates(Book B);
    
   
}
