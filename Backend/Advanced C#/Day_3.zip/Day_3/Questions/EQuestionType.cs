﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day_3.Questions
{
    public enum EQuestionType
    {
        MCQ,
        TrueFalse,
        MultipleMCQ
    }
}
